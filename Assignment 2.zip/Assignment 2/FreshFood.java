/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment1;

import java.util.Date;
import java.util.Scanner;

/**
 *New class with fresh foods and experation dates
 * @author Tonni
 */
public class FreshFood extends FoodItem  {
    
    private String ExpirationDate;
    private boolean refrigerated;
	
	public FreshFood(String name, String brand,String UPC, String prodate, int weight, int age, String expdate, boolean refrigerated) {
		super();
		this.ExpirationDate = expdate;
		this.refrigerated = refrigerated;
	}


	
public String getexpdate() {
	return ExpirationDate;
}

 public void setexpdate(String expdate) {
		 
		 String regex = "[0-9]{4}-[0-9]{2}-[0-9]{2}";
		 
		 if ( !expdate.matches(regex) )
			 return;
		 
	this.ExpirationDate = expdate;
}

public boolean getrefrigerated() {
	return refrigerated;
	
}
public void setrefrigerated() {
	Scanner input = new Scanner(System.in);
	System.out.println("Is it Refrigerated? Answer Y/N:");
	char fridge = input.next().charAt(0);
	
	if (fridge == 'Y' || fridge == 'y') {
		System.out.println("It is prepackaged");
		this.refrigerated = true;
	}
	
	if (fridge == 'N' || fridge == 'n') {
		System.out.println("It is not prepackaged");
		this.refrigerated = false;
	}
	else 
		System.out.println("You did not answer Y/N:");
	input.close();
		setrefrigerated();
}
    
}
