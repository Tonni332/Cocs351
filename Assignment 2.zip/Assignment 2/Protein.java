/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment1;

import java.util.Scanner;
/**
 *
 * @author Tonni
 */
public class Protein extends FreshFood{
    
    // Type of meat
	private String Type2;
	
	// Protein is Packaged?
	private Boolean Prepackaged;
        {
        
            
        }

    public Protein(String name, String brand, String UPC, String prodate, int weight, int age, String expdate, boolean refrigerated) {
        super(name, brand, UPC, prodate, weight, age, expdate, refrigerated);
    }
    this.Type2 = Type2;
	this.prepackage= prepackage;
}

public String gettype() {
	return Type2;
}

public void settype2() {
	Scanner input = new Scanner(System.in);
	System.out.println("Press '1' for Cattle, Press '2' for Game, Press '3' for Fish, Press '4' for Poultry");
	int freshtype = input.nextInt();
	
	switch(freshtype) {
	case 1: 
		this.Type2 = "Cattle"; break;
	case 2: 
		this.Type2 = "Game"; break;
	case 3: 
		this.Type2 = "Fish"; break;
	case 4:
		this.Type2 = "Poultry"; break;
	default:
		System.out.println("This is not valid! Pick one of the options!");
		input.close();
		settype();
		
	}
	

	
}
public boolean getPrepackaged() {
	return Prepackaged;
}
public void setPrepackaged() {
	
	Scanner input = new Scanner(System.in);
	System.out.println("Is it prepackaged? Answer Y/N:");
	char pack = input.next().charAt(0);
	
	if (pack == 'Y' || pack == 'y') {
		System.out.println("It is prepackaged");
		this.Prepackaged= true;
	}
	
	if (pack == 'N' || pack == 'n') {
		System.out.println("It is not prepackaged");
		this.Prepackaged = false;
	}
	else 
		System.out.println("You did not answer Y/N:");
		input.close();
		setPrepackaged();
}
