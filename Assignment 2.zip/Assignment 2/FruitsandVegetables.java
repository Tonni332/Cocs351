/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment1;

import java.util.Scanner;

/**
 * Extention of Assignment one to assingment 2 
 * @author Tonni
 */
public class FruitsandVegetables extends FreshFood {
    
    public FruitsandVegetables(String name, String brand, String UPC, String prodate, int weight, int age, String expdate, boolean refrigerated) {
        super(name, brand, UPC, prodate, weight, age, expdate, refrigerated);
    }
	private String Farm;
	private String Season;

public String getFarm() {
	return Farm;
}

 public void setname(String newFarm) {
		 
	 
	 String regex = "[a-zA-z0-9]+$";
	 if ( !newFarm.matches(regex) )
		 return;
		 if ( newFarm.length() < 2 || newFarm.length() > 50 ) {
			 System.out.println("You have entered an incorrect name. It must be at least 2 characters short and no greater than 50 characters long. Try again.");
		 	java.util.Scanner input = new java.util.Scanner(System.in);
		 	String retryFarm = input.nextLine();
		 	input.close();
		 	setname(retryFarm);
		 }
		 
	 	else {
	 		this.Farm = newFarm;
	 	}
}

public String getseason() {
	return Season;
	
}

public void setSeason() {
	Scanner input = new Scanner(System.in);
	System.out.println("Press '1' for Spring, Press '2' for Summer, Press '3' for Fall, Press '4' for Winter, Press '5' for Mixed");
	int seasonal = input.nextInt();
	
	switch(seasonal) {
	case 1: this.Season = "Spring"; break;
	case 2: this.Season = "Summer"; break;
	case 3: this.Season = "Fall"; break;
	case 4: this.Season = "Winter"; break;
	case 5: this.Season = "Mixed"; break;
	default: this.Season = "try again!";
        }
 }
}
