package assignment1;

import java.util.Scanner;
/**
 * This main structure from assignment1
 * @author Brittonni Shedrick
 * @since 2019-02-16
 * @version 1.0
 */

public class Assignment1 {

	/**
	 * Main function for Assignment 1
	 * @param args String array containing any arguments 
	 */
	public static void main(String[] args) {
		System.out.println("Solution to Assignment 1");
		
		FoodItem item = new FoodItem();
                
		
		// General comment: for this assignment we will assume that
		// the user always enters the correct information. If the user
		// is expected to enter a number, the assumption is that the user
		// will actually enter a number, thus it will not perform error-checking.
		
		Scanner userInput = new Scanner(System.in);
		
		System.out.println("Getting ready to populate an object of type FoodItem...");
		
		// Getting the name of the product
		System.out.print("Enter the name of the product: ");
		// The .trim() eliminates any leading or trailing whitespace
		item.setName(userInput.nextLine().trim());
		
		// Getting the brand of the product
		System.out.print("Enter the brand of the product: ");
		item.setBrand(userInput.nextLine().trim());
		
		// Getting the product's UPC
		System.out.print("Enter the UPC (12 digits): ");
		item.setUpc(Long.parseLong(userInput.nextLine()));
		
		// Getting the production date of the product
		System.out.print("Enter the production date: ");
		item.setProductionDate(userInput.nextLine());
		
		// Getting the unit weight of the product
		System.out.print("Enter the unit weight of the product: ");
		item.setUnitWeight(Double.parseDouble(userInput.nextLine()));
		
		userInput.close();
		
		// Outputting the information collected
		System.out.println("This is the information you entered for the product:");
		System.out.println(item);
	}

}
