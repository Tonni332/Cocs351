/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment1;

import java.util.Scanner;

/**
 * Assignment2 extention of assignment1 Categorzing precooked foods values
 * @author Tonni
 * 3/12/2019
 */
public class Precooked extends ProcessedFood {
    // Name of the product
	private String Ingredients;
        private Boolean Frozen;
	

public  String getingredient() {
	return Ingredients;
	
}
public void setingredient(String Newingredients) {
	 
	String regex = "[a-zA-z0-9]+$";
	 if ( !Newingredients.matches(regex) )
		 return;
	this.Ingredients = Ingredients;
}

public boolean getfrozen() {
	return Frozen;
}

public void setfrozen() {
	Scanner input = new Scanner(System.in);
	System.out.println("Is it frozen? Answer Y/N:");
	char froze = input.next().charAt(0);
	
	if (froze == 'Y' || froze == 'y') {
		System.out.println("It is Frozen");
		this.Frozen = true;
	}
	
	if (froze == 'N' || froze == 'n') {
		System.out.println("It is not Frozen");
		this.Frozen = false;
	}
	else 
		System.out.println("You did not answer Y/N:");
	input.close();
		setfrozen();

}  

}
