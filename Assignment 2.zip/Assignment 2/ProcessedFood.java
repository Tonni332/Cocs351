/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment1;

import java.util.Scanner;

/**
 *
 * @author Tonni
 */
public class ProcessedFood extends FoodItem {
    // Type of packaging
	private String Packaging;
        private String ExpirationDate;

public String getpackaged() {
	return Packaging;
}
public void setpackaged() {
	Scanner input = new Scanner(System.in);
	System.out.println("Press '1' for Plastic, Press '2' for Metal, Press '3' for Paper, Press '4' for None");
	int choice = input.nextInt();
	
	switch(choice) {case 1: this.Packaging = "Plastic"; break;
	case 2: this.Packaging = "Metal"; break;
	case 3: this.Packaging = "Paper"; break;
	case 4: this.Packaging = "None";
	default: this.Packaging = "try again!";
		
	}
	
	this.Packaging = Packaging;
	
}
public String getdate2() {
	return ExpirationDate;
}

 public void setdate2(String date2) {
		 
		 String regex = "[0-9]{4}-[0-9]{2}-[0-9]{2}";
		 
		 if ( !ExpirationDate.matches(regex) )
			 return;
		
	
	
	this.ExpirationDate = ExpirationDate;
}
}
