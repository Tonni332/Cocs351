/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment1;

import java.util.Scanner;

/**
 * Extenion from assignment1, to assignment 2 build Catagory attibutes
 * @author Brittonni/Tonni
 */
public class Cheese extends ProcessedFood {
    //Private attibutes 
    private String MilkType;
    
    private String Origin;
    
public String getmilk() {
	return MilkType;
}

public void setmilk() {
	//types of milk
	Scanner input = new Scanner(System.in);
	System.out.println("Press '1' for Cow, Press '2' for Sheep, Press '3' for Goat, Press '4' for Buffalo, Press '5' for Mixed ");
	int MilkType = input.nextInt();
	
	switch(MilkType) {
	case 1: this.MilkType = "Cow"; break;
	case 2: this.MilkType = "Sheep"; break;
	case 3: this.MilkType = "Goat"; break;
	case 4: this.MilkType = "Buffalo";
	case 5: this.MilkType = "Mixed";
	default: this.MilkType = "try again!";
		
	}
	
	this.MilkType = Origin;
}
//countries of origin
public String getorigin() {
	return Origin;
}
public void setorigin() { 
	this.Origin = Origin;
}
}
