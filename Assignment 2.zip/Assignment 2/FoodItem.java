package assignment1;

/**
 * This class partially satisfies the requirements of Assignment 1
 * @author Brittonni/Tonni
 * @version 1.0
 */

public class FoodItem {
	// Private attributes
	
	// Name of the product
	private String name;
	
	// Brand of the product
	private String brand;
	
	// UPC - 12-digit integer
	private long upc;
	
	// Date when the item was produced
	private String productionDate;
	
	// Weight of the unit - real number
	private double unitWeight;
	
	// Public methods
	
	/**
	 * Getter used to access the name of the product.
	 * @return A String containing the name of the product.
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Setter used to modify the name of the product.
	 * @param name A String containing the name of the product
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Getter used to access the brand of the product.
	 * @return A String containing the brand of the product
	 */
	public String getBrand() {
		return brand;
	}
	
	/**
	 * Setter used to modify the brand of the product.
	 * @param brand A String containing the brand of the product
	 */
	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	/**
	 * Getter used to access the UPC of the product.
	 * @return A long containing the UPC of the product
	 */
	public long getUpc() {
		return upc;
	}
	
	/**
	 * Setter used to modify the UPC of the product.
	 * @param upc A String containing the UPC of the product
	 */
	public void setUpc(long upc) {
		this.upc = upc;
	}
	
	/**
	 * Getter used to access the production date of the product.
	 * @return A String containing the production date of the product
	 */
	public String getProductionDate() {
		return productionDate;
	}
	
	/**
	 * Setter used to modify the production date of the product.
	 * @param productionDate A String containing the production date of the product
	 */
	public void setProductionDate(String productionDate) {
		this.productionDate = productionDate;
	}
	
	/**
	 * Getter used to access the unit weight of the product.
	 * @return A double containing the unit weight of the product
	 */
	public double getUnitWeight() {
		return unitWeight;
	}
	
	/**
	 * Setter used to modify the unit weight of the product.
	 * @param unitWeight A String containing the unit weight of the product
	 */
	public void setUnitWeight(double unitWeight) {
		this.unitWeight = unitWeight;
	}
	
	public String toString() {
		String toReturn = "Product name: " + name + "\n";
		toReturn += "Brand: " + brand + "\n";
		toReturn += "UPC: " + upc + "\n";
		toReturn += "Production date: " + productionDate + "\n";
		toReturn += "Unit weight: " + unitWeight + "\n";
		return toReturn;
	}
}
