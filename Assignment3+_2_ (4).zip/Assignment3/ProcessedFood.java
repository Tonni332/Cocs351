package assignment3;

import java.time.LocalDate;

/**
 * Assignment 3 Stackable
 * COSC 371 Giovanni Vincenti
 *4/9/2019
 * @author Brittonni/Tonni Shedrick
 */
public abstract class ProcessedFood extends FoodItem 
      implements Stackable{

}
{
	public ProcessedFood() {
		packaging = "";
		expirationDate = "0000-00-00";
	}
	private String packaging;
	private String expirationDate;
	
	private String[] packagingOptions = {"Plastic", "Metal", "Paper", "None"};
	
	public String getPackaging() {
		return packaging;
	}
	
	public boolean setPackaging(String packaging) {
		if ( packaging == null )
			return false;
		
		for ( String option : packagingOptions ) {
			if ( option.equalsIgnoreCase(packaging) ) {
				this.packaging = option;
				return true;
			}
		}
		
		return false;
	}
	
	public String getExpirationDate() {
		return expirationDate;
	}
	
	public boolean setExpirationDate(String expirationDate) {
		if ( !Utilities.validDateFormat(expirationDate) )
			return false;
		
		if ( expirationDate.equalsIgnoreCase("0000-00-00") ) {
			this.expirationDate = expirationDate;
			return true;
		}
		
		String[] dateElements = expirationDate.split("-");
		LocalDate expDate = LocalDate.of(Integer.parseInt(dateElements[0]), Integer.parseInt(dateElements[1]), Integer.parseInt(dateElements[2]));
		
		dateElements = getProductionDate().split("-");
		LocalDate productionDate = LocalDate.of(Integer.parseInt(dateElements[0]), Integer.parseInt(dateElements[1]), Integer.parseInt(dateElements[2]));;
		
		if ( expDate.atStartOfDay().isBefore(productionDate.atStartOfDay()) )
			return false;
		
		if ( expDate.atStartOfDay().isAfter(productionDate.plusYears(5).atStartOfDay()) )
			return false;
		
		this.expirationDate = expirationDate;
		return true;
	}
	
	public String toString() {
		String toReturn = super.toString();
		toReturn += "Packaging type: " + packaging + "\n";
		toReturn += "Expiration date: " + expirationDate + "\n";
		return toReturn;
	}
}
