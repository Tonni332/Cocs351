package assignment3;

import java.time.Duration;
import java.time.LocalDate;

/**
/**
 * Assignment 3 Stackable
 * COSC 371 Giovanni Vincenti
 *4/9/2019
 * @author Brittonni/Tonni Shedrick
 */

public abstract class FoodItem 

              implements Stackable{

}
{
	public FoodItem() {
		name = "";
		brand = "";
		upc = 0;
		productionDate = "0000-00-00";
		unitWeight = 0;
	}
	// Private attributes
	
	// Name of the product
	private String name;
	
	// Brand of the product
	private String brand;
	
	// UPC - 12-digit integer
	private long upc;
	
	// Date when the item was produced
	private String productionDate;
	
	// Weight of the unit - real number
	private double unitWeight;
	
	// Product Age
	private int productAge;
	
	// Public methods
	
	/**
	 * Getter used to access the name of the product.
	 * @return A String containing the name of the product.
	 */
private int number = 0;

  public void setMaxStackCount(int MaxStackCount) 
{ this.MaxStackCount = MaxStackCount; }
  public int getMaxStackCount() { return this.number; }
	
	
	/**
	 * Setter used to modify the name of the product.
	 * @param name A String containing the name of the product
	 */
	public boolean setName(String name) {
		if ( !Utilities.validString(name) )
			return false;
		
		this.name = name;
		return true;
	}
	
	/**
	 * Getter used to access the brand of the product.
	 * @return A String containing the brand of the product
	 */
	public String getBrand() {
		return brand;
	}
	
	/**
	 * Setter used to modify the brand of the product.
	 * @param brand A String containing the brand of the product
	 */
	public boolean setBrand(String brand) {
		if ( !Utilities.validString(brand) )
			return false;
		
		this.brand = brand;
		return true;
	}
	
	/**
	 * Getter used to access the UPC of the product.
	 * @return A long containing the UPC of the product
	 */
	public long getUpc() {
		return upc;
	}
	
	/**
	 * Setter used to modify the UPC of the product.
	 * @param upc A String containing the UPC of the product
	 */
	public boolean setUpc(long upc) {
		if ( upc < 100000000000l || upc > 999999999999l ) return false;
		
		this.upc = upc;
		return true;
	}
	
	/**
	 * Getter used to access the production date of the product.
	 * @return A String containing the production date of the product
	 */
	public String getProductionDate() {
		return productionDate;
	}
	
	/**
	 * Setter used to modify the production date of the product.
	 * @param productionDate A String containing the production date of the product
	 */
	public boolean setProductionDate(String productionDate) {
		if ( !Utilities.validDateFormat(productionDate) )
			return false;
		
		// Dividing the date into elements (year, month, day) and storing them in an array
		String[] dateElements = productionDate.split("-");
		// Index 0 contains the year, in String format
		// Index 1 contains the month, in String format
		// Index 2 contains the day, in String format
		LocalDate targetDate = LocalDate.of(Integer.parseInt(dateElements[0]), Integer.parseInt(dateElements[1]), Integer.parseInt(dateElements[2]));
		LocalDate now = LocalDate.now();
		
		if ( targetDate.isBefore(now) || targetDate.isEqual(now) ) {
			this.productionDate = productionDate;
			productAge = (int)(Duration.between(targetDate.atStartOfDay(), now.atStartOfDay())).toDays();
			return true;
		}
		
		return false;
	}
	
	/**
	 * Getter used to access the unit weight of the product.
	 * @return A double containing the unit weight of the product
	 */
	public double getUnitWeight() {
		return unitWeight;
	}
	
	/**
	 * Setter used to modify the unit weight of the product.
	 * @param unitWeight A String containing the unit weight of the product
	 */
	public boolean setUnitWeight(double unitWeight) {
		if ( unitWeight <= 0d ) return false;
		
		this.unitWeight = unitWeight;
		return true;
	}
	
	/**
	 * Getter used to access the calculated value of the product's age.
	 * @return An int containing the age of the product in days
	 */
	public int getProductAge() {
		return productAge;
	}
	
	public String toString() {
		String toReturn = "Product name: " + name + "\n";
		toReturn += "Brand: " + brand + "\n";
		toReturn += "UPC: " + upc + "\n";
		toReturn += "Production date: " + productionDate + " (age: " + productAge + " days)\n";
		toReturn += "Unit weight: " + unitWeight + "\n";
		return toReturn;
	}
}
