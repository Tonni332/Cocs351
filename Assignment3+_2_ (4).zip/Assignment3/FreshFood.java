package assignment3;
/**
 * Assignment 3 Stackable
 * COSC 371 Giovanni Vincenti
 *4/9/2019
 * @author Brittonni/Tonni Shedrick
 */
import java.time.LocalDate;

public abstract class FreshFood extends FoodItem 

        implements Stackable{

}

{
	public FreshFood() {
		refrigerated = true;
		expirationDate = LocalDate.now().toString();
	}
	private String expirationDate;
	private boolean refrigerated;
	
	public String getExpirationDate() {
		return expirationDate;
	}
	
	public boolean setExpirationDate(String expirationDate) {
		if ( !Utilities.validDateFormat(expirationDate) )
			return false;
		
		String[] dateElements = expirationDate.split("-");
		LocalDate expDate = LocalDate.of(Integer.parseInt(dateElements[0]), Integer.parseInt(dateElements[1]), Integer.parseInt(dateElements[2]));
		
		dateElements = getProductionDate().split("-");
		LocalDate productionDate = LocalDate.of(Integer.parseInt(dateElements[0]), Integer.parseInt(dateElements[1]), Integer.parseInt(dateElements[2]));;
		
		if ( expDate.atStartOfDay().isBefore(productionDate.atStartOfDay()) )
			return false;
		
		if ( expDate.atStartOfDay().isAfter(productionDate.plusMonths(1).atStartOfDay()) )
			return false;
		
		this.expirationDate = expirationDate;
		return true;
	}
	
	public boolean isRefrigerated() {
		return refrigerated;
	}
	
	public boolean setRefrigerated(boolean refrigerated) {
		this.refrigerated = refrigerated;
		return true;
	}
	
	public String toString() {
		String toReturn = super.toString();
		toReturn += "Expiration date: " + expirationDate + "\n";
		toReturn += "Refrigerated: " + (refrigerated?"Yes":"No") + "\n";
		return toReturn;
	}
}
