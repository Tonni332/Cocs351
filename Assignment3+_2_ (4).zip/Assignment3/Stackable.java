package assignment3;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Assignment 3 Stackable
 * COSC 371 Giovanni Vincenti
 *4/9/2019
 * @author Brittonni/Tonni Shedrick
 */
interface Stackable {
    
     Boolean Stackable;
     return = true
     
    int MaxStackCount= 1;

public int setMaxStackCount(int num);{
    
}
    String StackDescription;
    
  Boolean isStackable 
 setStackable
 setMaxStackCount (integer data type, if an item is stackable then this must be at least 1)
getMaxStackCount
setStackDescription (String data type, contains instructions on how to stack the items)
 getStackDescription
    
    public boolean setStackable() {
        double utilites = 0;
		if ( !utilites <= 0d ) {
                    return false;
                }
		
		this.Stackable = Stackable;
		return true;
    }
public String getStackDescription() {
		return StackDescription;
}

 void setNumber(int num); // public is implicit in interfaces
  int getNumber();         // obviously
}

